CREATE DATABASE IF NOT EXISTS portfolio_db;
USE portfolio_db;

CREATE TABLE admins (
id INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(50),
password VARCHAR(255)
);

INSERT INTO admins (username,password)
VALUES ('admin', MD5('admin123'));

CREATE TABLE projects (
id INT AUTO_INCREMENT PRIMARY KEY,
title VARCHAR(100),
description TEXT
);

CREATE TABLE messages (
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(100),
email VARCHAR(100),
message TEXT
);
