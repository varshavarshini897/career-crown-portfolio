<?php 
require_once 'config/db.php';
include 'includes/header.php';

// SAFE QUERY
function safeQuery($conn, $sql) {
    $res = $conn->query($sql);
    return $res ?: false;
}

// PROFILE
$profile = null;
$pq = safeQuery($conn, "SELECT * FROM profile LIMIT 1");
if ($pq && $pq->num_rows > 0) {
    $profile = $pq->fetch_assoc();
}

// STATS
$totalProjects = safeQuery($conn, "SELECT COUNT(*) AS total FROM projects")->fetch_assoc()['total'] ?? 0;
$totalSkills   = safeQuery($conn, "SELECT COUNT(*) AS total FROM skills")->fetch_assoc()['total'] ?? 0;
$totalMessages = safeQuery($conn, "SELECT COUNT(*) AS total FROM messages")->fetch_assoc()['total'] ?? 0;

// PROJECTS
$projects = safeQuery($conn, "SELECT * FROM projects ORDER BY id DESC LIMIT 3");

// SKILLS
$skills = safeQuery($conn, "SELECT * FROM skills ORDER BY level DESC LIMIT 6");
?>

<!-- HERO -->
<section class="hero-section">
<div class="container hero-grid">

<div class="hero-content">

<span class="badge">Dynamic Portfolio System</span>

<h1>
<?= e($profile['full_name'] ?? 'Career Crown') ?>
<span>Portfolio</span>
</h1>

<p class="hero-subtitle">
<?= e($profile['title'] ?? 'Full Stack Developer') ?>
</p>

<p class="hero-description">
<?= e($profile['about'] ?? 'Modern PHP Portfolio System') ?>
</p>

<div class="hero-buttons">
<a href="<?= BASE_URL ?>projects.php" class="btn">Explore Projects</a>
<a href="<?= BASE_URL ?>contact.php" class="btn btn-outline">Contact</a>
</div>

</div>

<!-- CLEAN RIGHT SIDE -->
<div class="hero-card">
    <h3>Welcome 👋</h3>
    <p>
        This is a dynamic portfolio system where projects, skills and messages
        are fully managed through admin panel.
    </p>
</div>

</div>
</section>

<!-- STATS -->
<section class="stats-section">
<div class="container stats-grid">

<div class="stat-card">
<h2><?= (int)$totalProjects ?></h2>
<p>Projects</p>
</div>

<div class="stat-card">
<h2><?= (int)$totalSkills ?></h2>
<p>Skills</p>
</div>

<div class="stat-card">
<h2><?= (int)$totalMessages ?></h2>
<p>Messages</p>
</div>

</div>
</section>

<!-- PROJECTS -->
<section class="section">
<div class="container">

<h2>Latest Projects</h2>

<div class="project-grid">

<?php if ($projects && $projects->num_rows > 0): ?>
<?php while ($p = $projects->fetch_assoc()): ?>

<div class="project-card">

<?php if (!empty($p['image'])): ?>
<img src="<?= BASE_URL ?>uploads/projects/<?= e($p['image']) ?>">
<?php endif; ?>

<h3><?= e($p['title']) ?></h3>

<p><?= e(substr($p['description'],0,100)) ?>...</p>

<div class="tech-stack">
<?= e($p['tech_stack'] ?? '') ?>
</div>

</div>

<?php endwhile; ?>
<?php else: ?>

<div class="empty-box">
<h3>No Projects Yet</h3>
<p>Add projects from admin panel</p>
</div>

<?php endif; ?>

</div>
</div>
</section>

<!-- SKILLS -->
<section class="section dark-section">
<div class="container">

<h2>Top Skills</h2>

<div class="skills-grid">

<?php if ($skills && $skills->num_rows > 0): ?>
<?php while ($s = $skills->fetch_assoc()): ?>

<div class="skill-card">

<h4><?= e($s['name']) ?></h4>

<div class="progress-bar">
<div style="width: <?= (int)$s['level'] ?>%"></div>
</div>

<small><?= e($s['type']) ?></small>

</div>

<?php endwhile; ?>
<?php else: ?>

<div class="empty-box">
<h3>No Skills Found</h3>
<p>Add skills from admin panel</p>
</div>

<?php endif; ?>

</div>
</div>
</section>

<?php include 'includes/footer.php'; ?>