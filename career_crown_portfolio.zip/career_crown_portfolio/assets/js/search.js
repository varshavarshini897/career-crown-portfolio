document.addEventListener("DOMContentLoaded", function () {

    const searchInput = document.getElementById("searchInput");
    const noResult = document.getElementById("noResult");

    function filterProjects() {

        const cards = document.querySelectorAll(".project-card"); // 🔥 moved inside
        const value = searchInput.value.toLowerCase();

        let visible = 0;

        cards.forEach(card => {

            const text = card.innerText.toLowerCase();

            if (text.includes(value)) {
                card.style.display = "";
                visible++;
            } else {
                card.style.display = "none";
            }

        });

        // show no result message
        if (noResult) {
            noResult.style.display = visible === 0 ? "block" : "none";
        }
    }

    if (searchInput) {
        searchInput.addEventListener("keyup", filterProjects);
    }

});