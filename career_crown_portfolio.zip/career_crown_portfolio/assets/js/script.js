// ===============================
// WAIT FOR DOM
// ===============================
document.addEventListener("DOMContentLoaded", () => {

    // ===============================
    // MOBILE MENU TOGGLE
    // ===============================
    window.toggleMenu = function () {
        const menu = document.getElementById("navMenu");
        if (menu) menu.classList.toggle("show");
    };

    // ===============================
    // AUTO CLOSE MENU
    // ===============================
    document.querySelectorAll("#navMenu a").forEach(link => {
        link.addEventListener("click", () => {
            const menu = document.getElementById("navMenu");
            if (menu) menu.classList.remove("show");
        });
    });

    // ===============================
    // SMOOTH SCROLL
    // ===============================
    document.querySelectorAll("a[href^='#']").forEach(anchor => {
        anchor.addEventListener("click", function (e) {
            const href = this.getAttribute("href");

            if (!href || href === "#") return;

            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: "smooth" });
            }
        });
    });

    // ===============================
    // BUTTON RIPPLE EFFECT
    // ===============================
    document.querySelectorAll(".btn").forEach(btn => {
        btn.addEventListener("click", function (e) {

            const circle = document.createElement("span");
            circle.className = "ripple";

            const rect = this.getBoundingClientRect();
            circle.style.left = (e.clientX - rect.left) + "px";
            circle.style.top = (e.clientY - rect.top) + "px";

            this.appendChild(circle);

            setTimeout(() => circle.remove(), 500);
        });
    });

    // ===============================
    // INPUT FOCUS EFFECT
    // ===============================
    document.querySelectorAll("input, textarea").forEach(input => {
        input.addEventListener("focus", () => {
            input.parentElement?.classList.add("focused");
        });

        input.addEventListener("blur", () => {
            if (!input.value) {
                input.parentElement?.classList.remove("focused");
            }
        });
    });

});

// ===============================
// SCROLL NAVBAR EFFECT
// ===============================
window.addEventListener("scroll", () => {
    const navbar = document.querySelector(".navbar");
    if (!navbar) return;

    navbar.classList.toggle("scrolled", window.scrollY > 50);
});

// ===============================
// AUTO HIDE ALERTS
// ===============================
setTimeout(() => {
    document.querySelectorAll(".alert").forEach(alert => {
        alert.style.opacity = "0";
        setTimeout(() => alert.remove(), 400);
    });
}, 3000);

// ===============================
// CONFIRM DELETE (GLOBAL)
// ===============================
function confirmDelete(msg = "Are you sure?") {
    return confirm(msg);
}

// ===============================
// PROGRESS BAR ANIMATION
// ===============================
window.addEventListener("load", () => {
    document.querySelectorAll(".progress-bar div").forEach(bar => {

        const width = bar.style.width;
        if (!width) return;

        bar.style.width = "0";

        setTimeout(() => {
            bar.style.width = width;
        }, 300);
    });
});