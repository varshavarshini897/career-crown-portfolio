<?php 
require_once 'config/db.php';
include 'includes/header.php';

// FETCH PROJECTS
$result = $conn->query("SELECT * FROM projects ORDER BY id DESC");
?>

<section class="section">
<div class="container">

    <div class="section-heading">
        <span>Portfolio</span>
        <h2>All Projects</h2>
        <p>Projects dynamically managed via admin panel</p>
    </div>

    <!-- SEARCH + FILTER -->
    <div class="filter-bar">
        <input type="text" id="searchProject" placeholder="Search projects...">

        <select id="categoryFilter">
            <option value="">All Categories</option>
            <option value="web">Web</option>
            <option value="app">App</option>
            <option value="system">System</option>
        </select>
    </div>

    <!-- GRID -->
    <div class="project-grid" id="projectContainer">

        <?php if ($result && $result->num_rows > 0): ?>

            <?php while ($row = $result->fetch_assoc()): ?>

                <?php $category = strtolower($row['category'] ?? 'web'); ?>

                <div class="project-card" 
                     data-category="<?= e($category) ?>">

                    <!-- IMAGE -->
                    <div class="project-image">
                        <?php if (!empty($row['image'])): ?>
                            <img src="<?= BASE_URL ?>uploads/projects/<?= e($row['image']) ?>" 
                                 alt="<?= e($row['title']) ?>">
                        <?php else: ?>
                            <div class="image-placeholder">
                                <?= strtoupper(substr($row['title'], 0, 1)) ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- CONTENT -->
                    <div class="project-body">

                        <span class="project-category">
                            <?= e($row['category'] ?? 'Web') ?>
                        </span>

                        <h3><?= e($row['title']) ?></h3>

                        <p>
                            <?= e(substr($row['description'], 0, 120)) ?>...
                        </p>

                        <?php if (!empty($row['tech_stack'])): ?>
                        <div class="tech-stack">
                            <?= e($row['tech_stack']) ?>
                        </div>
                        <?php endif; ?>

                        <div class="project-footer">
                            <span class="status <?= strtolower($row['status'] ?? 'completed') ?>">
                                <?= e($row['status'] ?? 'Completed') ?>
                            </span>
                        </div>

                    </div>
                </div>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="empty-box">
                <h3>No Projects Found</h3>
                <p>Projects will appear here after adding from admin panel.</p>
            </div>

        <?php endif; ?>

    </div>

    <!-- NO RESULT -->
    <div id="noResults" class="empty-box" style="display:none;">
        <h3>No matching projects</h3>
        <p>Try different search or filter</p>
    </div>

</div>
</section>

<!-- 🔥 FIXED JS -->
<script>

document.addEventListener("DOMContentLoaded", function () {

    const searchInput = document.getElementById("searchProject");
    const categoryFilter = document.getElementById("categoryFilter");
    const noResults = document.getElementById("noResults");

    function filterProjects() {

        const cards = document.querySelectorAll(".project-card"); // 🔥 important fix

        const search = searchInput.value.toLowerCase();
        const category = categoryFilter.value;

        let visible = 0;

        cards.forEach(card => {

            const text = card.innerText.toLowerCase();
            const cardCategory = card.dataset.category;

            const matchSearch = text.includes(search);
            const matchCategory = !category || cardCategory === category;

            if (matchSearch && matchCategory) {
                card.style.display = "";
                visible++;
            } else {
                card.style.display = "none";
            }

        });

        // SHOW NO RESULT
        if (noResults) {
            noResults.style.display = visible === 0 ? "block" : "none";
        }
    }

    // EVENTS
    if (searchInput) {
        searchInput.addEventListener("keyup", filterProjects);
    }

    if (categoryFilter) {
        categoryFilter.addEventListener("change", filterProjects);
    }

});

</script>

<?php include 'includes/footer.php'; ?>