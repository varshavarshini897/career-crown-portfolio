<?php
require_once 'config/db.php';
require_once 'includes/auth.php';

// 🔒 ONLY ADMIN ACCESS
require_admin();

// 🔒 DEBUG MODE CHECK
if (!defined('APP_DEBUG') || APP_DEBUG !== true) {
    die("Debug mode disabled.");
}

// ================= HELPER =================
function status($condition) {
    return $condition 
        ? "<span style='color:lime;'>✔ OK</span>" 
        : "<span style='color:red;'>❌ FAIL</span>";
}

// ================= UI =================
echo "<style>
body{background:#0f172a;color:#fff;font-family:sans-serif;padding:20px}
.card{background:#1e293b;padding:20px;margin-bottom:15px;border-radius:10px}
h2{color:#38bdf8}
small{color:#94a3b8}
</style>";

echo "<h2>🚀 SYSTEM DEBUG PANEL</h2>";


// ================= SERVER =================
echo "<div class='card'>";
echo "<h3>Server</h3>";
echo "<p>PHP Working: " . status(true) . "</p>";
echo "<p>PHP Version: " . e(phpversion()) . "</p>";
echo "<p>Server: " . e($_SERVER['SERVER_SOFTWARE'] ?? 'Unknown') . "</p>";
echo "</div>";


// ================= DATABASE =================
echo "<div class='card'>";
echo "<h3>Database</h3>";

$dbConnected = ($conn && !$conn->connect_error);
echo "<p>Connection: " . status($dbConnected) . "</p>";

if ($dbConnected) {

    $tables = ['projects', 'skills', 'messages', 'profile'];

    foreach ($tables as $table) {
        $stmt = $conn->prepare("SHOW TABLES LIKE ?");
        $stmt->bind_param("s", $table);
        $stmt->execute();
        $res = $stmt->get_result();

        echo "<p>Table '".e($table)."': " . status($res && $res->num_rows > 0) . "</p>";

        $stmt->close();
    }
}
echo "</div>";


// ================= SESSION =================
echo "<div class='card'>";
echo "<h3>Session</h3>";
echo "<p>Status: " . status(session_status() === PHP_SESSION_ACTIVE) . "</p>";
echo "<p>User Logged In: " . status(is_logged_in()) . "</p>";
echo "<p>Admin: " . status(is_admin()) . "</p>";
echo "</div>";


// ================= CONFIG =================
echo "<div class='card'>";
echo "<h3>Config</h3>";

echo "<p>BASE_URL: " . (defined('BASE_URL') 
    ? "<span style='color:lime;'>".e(BASE_URL)."</span>" 
    : "<span style='color:red;'>Not Defined</span>") . "</p>";

echo "<p>APP_DEBUG: " . status(defined('APP_DEBUG') && APP_DEBUG) . "</p>";

echo "</div>";


// ================= EXTENSIONS =================
echo "<div class='card'>";
echo "<h3>PHP Extensions</h3>";

$extensions = ['mysqli', 'mbstring', 'openssl'];

foreach ($extensions as $ext) {
    echo "<p>$ext: " . status(extension_loaded($ext)) . "</p>";
}
echo "</div>";


// ================= PATH =================
echo "<div class='card'>";
echo "<h3>Path</h3>";
echo "<p><small>File: " . e(__FILE__) . "</small></p>";
echo "<p><small>Root: " . e($_SERVER['DOCUMENT_ROOT'] ?? '') . "</small></p>";
echo "</div>";


// ================= WARNING =================
echo "<div class='card'>";
echo "<h3>⚠️ Security Notice</h3>";
echo "<p style='color:orange;'>Disable or delete this file in production!</p>";
echo "</div>";
?>