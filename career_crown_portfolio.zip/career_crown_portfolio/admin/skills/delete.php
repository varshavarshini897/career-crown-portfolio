<?php
require_once '../../config/db.php';
require_once '../../includes/auth.php';

require_admin();

// ONLY POST ALLOWED
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit;
}

// CSRF VERIFY
if (!isset($_POST['csrf']) || $_POST['csrf'] !== ($_SESSION['csrf'] ?? '')) {
    header("Location: index.php?error=csrf");
    exit;
}

// VALIDATE ID
if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    header("Location: index.php?error=invalid");
    exit;
}

$id = (int) $_POST['id'];

try {

    // CHECK EXIST
    $stmt = $conn->prepare("SELECT id FROM skills WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if (!$result || $result->num_rows === 0) {
        $stmt->close();
        header("Location: index.php?error=notfound");
        exit;
    }

    $stmt->close();

    // DELETE
    $stmt = $conn->prepare("DELETE FROM skills WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $stmt->close();
        header("Location: index.php?success=deleted");
    } else {
        $stmt->close();
        header("Location: index.php?error=failed");
    }

} catch (Exception $e) {

    // log error silently (optional)
    // error_log($e->getMessage());

    header("Location: index.php?error=server");
}

exit;
?>