<?php
require_once '../../config/db.php';
require_once '../../includes/auth.php';

require_admin();

$success = "";
$error = "";

// HANDLE POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF
    if (!isset($_POST['csrf']) || $_POST['csrf'] !== ($_SESSION['csrf'] ?? '')) {
        $error = "Invalid request!";
    } else {

        $name  = trim($_POST['name'] ?? '');
        $level = (int) ($_POST['level'] ?? 0);
        $type  = trim($_POST['type'] ?? '');

        // normalize
        $name = ucfirst(strtolower($name));
        $type = ucfirst(strtolower($type));

        // VALIDATION
        if (!$name) {
            $error = "Skill name required!";
        } elseif ($level < 0 || $level > 100) {
            $error = "Level must be between 0-100!";
        } elseif (!$type) {
            $error = "Skill type required!";
        } else {

            // CASE-INSENSITIVE DUPLICATE CHECK
            $check = $conn->prepare("SELECT id FROM skills WHERE LOWER(name)=LOWER(?)");
            $check->bind_param("s", $name);
            $check->execute();
            $res = $check->get_result();

            if ($res->num_rows > 0) {
                $error = "Skill already exists!";
            } else {

                $stmt = $conn->prepare("
                    INSERT INTO skills (name, level, type)
                    VALUES (?, ?, ?)
                ");

                $stmt->bind_param("sis", $name, $level, $type);

                if ($stmt->execute()) {
                    $success = "Skill added successfully!";

                    // reset form
                    $name = "";
                    $level = 80;
                    $type = "";
                } else {
                    $error = "Database error!";
                }

                $stmt->close();
            }

            $check->close();
        }
    }
}
?>

<!-- ✅ FIXED HEADER -->
<?php include __DIR__ . '/../../includes/header.php'; ?>

<div class="admin-container">

<h2>Add Skill</h2>

<?php if ($success): ?>
<div class="alert success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" class="admin-form">

<input type="hidden" name="csrf" value="<?= $_SESSION['csrf'] ?>">

<div class="form-group">
<label>Skill Name</label>
<input type="text" name="name"
value="<?= htmlspecialchars($name ?? '') ?>"
placeholder="e.g. HTML, PHP" required>
</div>

<div class="form-group">
<label>Skill Level (%)</label>
<input type="number" name="level" min="0" max="100"
value="<?= htmlspecialchars($level ?? 80) ?>">
</div>

<!-- 🔥 IMPROVED TYPE -->
<div class="form-group">
<label>Skill Type</label>
<select name="type" required>
<option value="">Select Type</option>
<option value="Frontend">Frontend</option>
<option value="Backend">Backend</option>
<option value="Database">Database</option>
</select>
</div>

<button type="submit" class="btn btn-primary">
Add Skill 🚀
</button>

</form>

</div>

<!-- ✅ FIXED FOOTER -->
<?php include __DIR__ . '/../../includes/footer.php'; ?>