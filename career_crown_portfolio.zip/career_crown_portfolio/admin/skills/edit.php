<?php
require_once '../../config/db.php';
require_once '../../includes/auth.php';

require_admin();

$success = "";
$error = "";

// VALIDATE ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET['id'];

// FETCH SKILL
$stmt = $conn->prepare("SELECT * FROM skills WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows === 0) {
    header("Location: index.php");
    exit;
}

$skill = $result->fetch_assoc();
$stmt->close();


// ================= UPDATE =================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF CHECK
    if (!isset($_POST['csrf']) || $_POST['csrf'] !== ($_SESSION['csrf'] ?? '')) {
        $error = "Invalid request!";
    } else {

        $name  = trim($_POST['name'] ?? '');
        $level = (int) ($_POST['level'] ?? 0);
        $type  = trim($_POST['type'] ?? '');

        // normalize type
        $type = ucfirst(strtolower($type));

        // VALIDATION
        if (!$name) {
            $error = "Skill name required!";
        } elseif ($level < 0 || $level > 100) {
            $error = "Level must be between 0-100!";
        } else {

            // DUPLICATE CHECK (excluding current)
            $check = $conn->prepare("SELECT id FROM skills WHERE name = ? AND id != ?");
            $check->bind_param("si", $name, $id);
            $check->execute();
            $res = $check->get_result();

            if ($res->num_rows > 0) {
                $error = "Skill already exists!";
            } else {

                $stmt = $conn->prepare("
                    UPDATE skills
                    SET name=?, level=?, type=?
                    WHERE id=?
                ");

                $stmt->bind_param("sisi", $name, $level, $type, $id);

                if ($stmt->execute()) {
                    $success = "Skill updated successfully!";

                    // update UI data
                    $skill['name'] = $name;
                    $skill['level'] = $level;
                    $skill['type'] = $type;

                } else {
                    $error = "Update failed!";
                }

                $stmt->close();
            }

            $check->close();
        }
    }
}
?>

<?php include '../partials/header.php'; ?>

<div class="admin-container">

<h2>Edit Skill</h2>

<?php if ($success): ?>
<div class="alert success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" class="admin-form">

<input type="hidden" name="csrf" value="<?= $_SESSION['csrf'] ?>">

<div class="form-group">
<label>Skill Name</label>
<input type="text" name="name"
value="<?= htmlspecialchars($skill['name']) ?>" required>
</div>

<div class="form-group">
<label>Skill Level (%)</label>
<input type="number" name="level" min="0" max="100"
value="<?= (int)$skill['level'] ?>">
</div>

<div class="form-group">
<label>Skill Type</label>
<input type="text" name="type"
value="<?= htmlspecialchars($skill['type']) ?>">
</div>

<button type="submit" class="btn btn-primary">
Update Skill 🚀
</button>

</form>

</div>

<?php include '../partials/footer.php'; ?>