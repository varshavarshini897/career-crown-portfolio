<?php
require_once '../../config/db.php';
require_once '../../includes/auth.php';

require_admin();

// FILTER INPUT
$search = $_GET['search'] ?? '';
$type   = $_GET['type'] ?? '';

// PAGINATION
$limit = 5;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// BUILD QUERY (SAFE)
$sql = "SELECT * FROM skills WHERE 1";
$params = [];
$types = "";

// SEARCH
if ($search) {
    $sql .= " AND name LIKE ?";
    $params[] = "%$search%";
    $types .= "s";
}

// FILTER TYPE
if ($type) {
    $sql .= " AND type = ?";
    $params[] = $type;
    $types .= "s";
}

// ORDER + LIMIT
$sql .= " ORDER BY id DESC LIMIT ?, ?";
$params[] = $offset;
$params[] = $limit;
$types .= "ii";

// PREPARE
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// TOTAL COUNT
$countSql = "SELECT COUNT(*) as total FROM skills WHERE 1";

$countStmt = $conn->prepare($countSql);
$countStmt->execute();
$total = $countStmt->get_result()->fetch_assoc()['total'];

$totalPages = ceil($total / $limit);
?>

<?php include '../partials/header.php'; ?>

<div class="admin-container">

<div class="admin-header">
<h2>Manage Skills (<?= $total ?>)</h2>

<a href="add.php" class="btn btn-primary">➕ Add Skill</a>
</div>

<!-- FILTER -->
<form method="GET" class="filter-bar">

<input type="text" name="search" placeholder="Search skill..."
value="<?= htmlspecialchars($search) ?>">

<select name="type">
<option value="">All Types</option>
<option value="Frontend" <?= $type=='Frontend'?'selected':'' ?>>Frontend</option>
<option value="Backend" <?= $type=='Backend'?'selected':'' ?>>Backend</option>
<option value="Database" <?= $type=='Database'?'selected':'' ?>>Database</option>
</select>

<button class="btn small">Filter</button>

</form>

<div class="table-container">

<table class="admin-table">

<thead>
<tr>
<th>ID</th>
<th>Skill</th>
<th>Level</th>
<th>Type</th>
<th>Actions</th>
</tr>
</thead>

<tbody>

<?php if ($result && $result->num_rows > 0): ?>

<?php while ($row = $result->fetch_assoc()): ?>

<tr>
<td><?= (int)$row['id'] ?></td>

<td><?= htmlspecialchars($row['name']) ?></td>

<td>
<div class="progress-bar">
<div style="width: <?= (int)$row['level'] ?>%"></div>
</div>
<small><?= (int)$row['level'] ?>%</small>
</td>

<td>
<span class="badge"><?= htmlspecialchars($row['type']) ?></span>
</td>

<td>

<a href="edit.php?id=<?= $row['id'] ?>" class="btn small">
✏️ Edit
</a>

<!-- SECURE DELETE -->
<form method="POST" action="delete.php" style="display:inline;">
<input type="hidden" name="id" value="<?= $row['id'] ?>">
<input type="hidden" name="csrf" value="<?= $_SESSION['csrf'] ?>">

<button class="btn small danger"
onclick="return confirm('Delete this skill?')">
🗑 Delete
</button>
</form>

</td>
</tr>

<?php endwhile; ?>

<?php else: ?>

<tr>
<td colspan="5">
<div class="empty-box">
<h3>No skills found</h3>
<p>Try adjusting filters.</p>
</div>
</td>
</tr>

<?php endif; ?>

</tbody>

</table>

</div>

<!-- PAGINATION -->
<div class="pagination">

<?php for ($i = 1; $i <= $totalPages; $i++): ?>

<a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&type=<?= urlencode($type) ?>"
class="<?= $i == $page ? 'active' : '' ?>">
<?= $i ?>
</a>

<?php endfor; ?>

</div>

</div>

<?php include '../partials/footer.php'; ?>