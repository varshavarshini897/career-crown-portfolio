<?php
require_once '../config/db.php';
require_once '../includes/auth.php';

require_admin();

// SEARCH
$search = trim($_GET['search'] ?? '');

// PAGINATION
$limit = 5;
$page = (isset($_GET['page']) && is_numeric($_GET['page'])) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// BASE QUERY
$where = "WHERE 1";
$params = [];
$types = "";

// SEARCH FILTER
if ($search !== '') {
    $where .= " AND (name LIKE ? OR email LIKE ? OR message LIKE ?)";
    $searchTerm = "%$search%";
    $params = [$searchTerm, $searchTerm, $searchTerm];
    $types = "sss";
}

// MAIN QUERY
$sql = "SELECT * FROM messages $where ORDER BY id DESC LIMIT ?, ?";
$params[] = $offset;
$params[] = $limit;
$types .= "ii";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// COUNT QUERY (FIXED)
$countSql = "SELECT COUNT(*) as total FROM messages $where";

if ($search !== '') {
    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
    $countStmt->execute();
    $total = $countStmt->get_result()->fetch_assoc()['total'] ?? 0;
    $countStmt->close();
} else {
    $total = $conn->query($countSql)->fetch_assoc()['total'] ?? 0;
}

$totalPages = ceil($total / $limit);
?>

<?php include '../includes/header.php'; ?>

<div class="admin-container">

<div class="admin-header">
<h2>Messages (<?= (int)$total ?>)</h2>
</div>

<!-- SEARCH -->
<form method="GET" class="filter-bar">
<input type="text" name="search" placeholder="Search messages..."
value="<?= e($search) ?>">
<button class="btn small">Search</button>
</form>

<div class="table-container">

<table class="admin-table">

<thead>
<tr>
<th>ID</th>
<th>Name</th>
<th>Email</th>
<th>Message</th>
<th>Date</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php if ($result && $result->num_rows > 0): ?>

<?php while ($row = $result->fetch_assoc()): ?>

<tr>
<td><?= (int)$row['id'] ?></td>

<td><?= e($row['name']) ?></td>

<td><?= e($row['email']) ?></td>

<td title="<?= e($row['message']) ?>">
<?= e(substr($row['message'], 0, 60)) ?>...
</td>

<td>
<?= date("d M Y", strtotime($row['created_at'])) ?>
</td>

<td>
<form method="POST" action="delete_message.php" style="display:inline;">
<input type="hidden" name="id" value="<?= $row['id'] ?>">
<input type="hidden" name="csrf" value="<?= csrf_token() ?>">

<button class="btn small danger"
onclick="return confirm('Delete this message?')">
🗑 Delete
</button>
</form>
</td>

</tr>

<?php endwhile; ?>

<?php else: ?>

<tr>
<td colspan="6">
<div class="empty-box">
<h3>No messages found</h3>
<p>No contact messages yet.</p>
</div>
</td>
</tr>

<?php endif; ?>

</tbody>

</table>

</div>

<!-- PAGINATION -->
<?php if ($totalPages > 1): ?>
<div class="pagination">

<?php for ($i = 1; $i <= $totalPages; $i++): ?>

<a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>"
class="<?= $i == $page ? 'active' : '' ?>">
<?= $i ?>
</a>

<?php endfor; ?>

</div>
<?php endif; ?>

</div>

<?php include '../includes/footer.php'; ?>