<?php
require_once '../config/db.php';
require_once '../includes/auth.php';

require_admin();

// ONLY POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/messages.php');
}

// CSRF VERIFY (helper)
verify_csrf();

// VALIDATE ID
if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    redirect('admin/messages.php?error=invalid');
}

$id = (int) $_POST['id'];

try {

    // CHECK EXIST
    $stmt = $conn->prepare("SELECT id FROM messages WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();

    if (!$res || $res->num_rows === 0) {
        $stmt->close();
        redirect('admin/messages.php?error=notfound');
    }

    $stmt->close();

    // DELETE
    $stmt = $conn->prepare("DELETE FROM messages WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $stmt->close();
        redirect('admin/messages.php?success=deleted');
    } else {
        $stmt->close();
        redirect('admin/messages.php?error=failed');
    }

} catch (Exception $e) {

    // optional logging
    // error_log($e->getMessage());

    redirect('admin/messages.php?error=server');
}