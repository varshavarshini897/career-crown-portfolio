<?php
require_once '../../config/db.php';
require_once '../../includes/auth.php';

require_admin();

// PAGINATION
$limit = 5;
$page = (isset($_GET['page']) && is_numeric($_GET['page'])) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// TOTAL
$totalRes = $conn->query("SELECT COUNT(*) as total FROM projects");
$total = $totalRes->fetch_assoc()['total'] ?? 0;
$totalPages = ceil($total / $limit);

// FETCH
$stmt = $conn->prepare("SELECT * FROM projects ORDER BY id DESC LIMIT ?, ?");
$stmt->bind_param("ii", $offset, $limit);
$stmt->execute();
$result = $stmt->get_result();
?>

<?php include '../../includes/header.php'; ?>

<div class="admin-container">

<h2>Manage Projects (<?= (int)$total ?>)</h2>

<a href="add.php" class="btn btn-primary">➕ Add Project</a>

<!-- SEARCH -->
<input type="text" id="searchInput" placeholder="Search projects..." class="search-box">

<div class="table-container">

<table class="admin-table">

<thead>
<tr>
<th>ID</th>
<th>Image</th>
<th>Title</th>
<th>Category</th>
<th>Status</th>
<th>Actions</th>
</tr>
</thead>

<tbody id="projectTable">

<?php if ($result && $result->num_rows > 0): ?>

<?php while ($row = $result->fetch_assoc()): ?>

<tr>

<td><?= (int)$row['id'] ?></td>

<td>
<?php if (!empty($row['image'])): ?>
<img src="<?= BASE_URL ?>uploads/projects/<?= e($row['image']) ?>" width="60">
<?php else: ?>
<span>No Image</span>
<?php endif; ?>
</td>

<td><?= e($row['title']) ?></td>

<td><?= e($row['category'] ?? '-') ?></td>

<td>
<span class="status <?= strtolower($row['status'] ?? 'completed') ?>">
<?= e($row['status'] ?? 'Completed') ?>
</span>
</td>

<td>

<a href="edit.php?id=<?= $row['id'] ?>" class="btn small">
✏️ Edit
</a>

<form method="POST" action="delete.php" style="display:inline;">
<input type="hidden" name="id" value="<?= $row['id'] ?>">
<input type="hidden" name="csrf" value="<?= csrf_token() ?>">

<button class="btn small danger"
onclick="return confirm('Delete this project?')">
🗑 Delete
</button>
</form>

</td>

</tr>

<?php endwhile; ?>

<?php else: ?>

<tr>
<td colspan="6">
<div class="empty-box">
<h3>No projects found</h3>
<p>Add new projects from admin panel</p>
</div>
</td>
</tr>

<?php endif; ?>

</tbody>

</table>

</div>

<!-- EMPTY SEARCH RESULT -->
<div id="noResult" class="empty-box" style="display:none;">
<h3>No matching projects</h3>
<p>Try different search keyword</p>
</div>

<!-- PAGINATION -->
<?php if ($totalPages > 1): ?>
<div class="pagination">

<?php for ($i = 1; $i <= $totalPages; $i++): ?>

<a href="?page=<?= $i ?>" 
class="<?= $i == $page ? 'active' : '' ?>">
<?= $i ?>
</a>

<?php endfor; ?>

</div>
<?php endif; ?>

</div>

<!-- SEARCH SCRIPT -->
<script>
const searchInput = document.getElementById("searchInput");
const rows = document.querySelectorAll("#projectTable tr");
const noResult = document.getElementById("noResult");

searchInput?.addEventListener("keyup", function() {

    const value = this.value.toLowerCase();
    let visible = 0;

    rows.forEach(row => {
        const text = row.innerText.toLowerCase();

        if (text.includes(value)) {
            row.style.display = "";
            visible++;
        } else {
            row.style.display = "none";
        }
    });

    if (noResult) {
        noResult.style.display = visible === 0 ? "block" : "none";
    }
});
</script>

<?php include '../../includes/footer.php'; ?>