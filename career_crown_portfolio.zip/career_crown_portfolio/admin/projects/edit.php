<?php
require_once '../../config/db.php';
require_once '../../includes/auth.php';

require_admin();

$success = "";
$error = "";

// UPLOAD DIR
$uploadDir = realpath(__DIR__ . '/../../uploads/projects/');
if (!$uploadDir) {
    $uploadDir = __DIR__ . '/../../uploads/projects/';
    mkdir($uploadDir, 0755, true);
}

// VALIDATE ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirect('admin/projects/index.php');
}

$id = (int) $_GET['id'];

// FETCH PROJECT
$stmt = $conn->prepare("SELECT * FROM projects WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if (!$result || $result->num_rows === 0) {
    redirect('admin/projects/index.php');
}

$project = $result->fetch_assoc();
$stmt->close();


// ================= UPDATE =================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verify_csrf();

    $title    = trim($_POST['title'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $tech     = trim($_POST['tech_stack'] ?? '');
    $desc     = trim($_POST['description'] ?? '');
    $status   = $_POST['status'] ?? 'Completed';

    $imageName = $project['image'];

    if (!$title || !$desc) {
        $error = "Title and Description required!";
    } else {

        // IMAGE UPDATE
        if (!empty($_FILES['image']['name'])) {

            $allowedExt  = ['jpg','jpeg','png','webp'];
            $allowedMime = ['image/jpeg','image/png','image/webp'];
            $maxSize     = 2 * 1024 * 1024;

            $tmp  = $_FILES['image']['tmp_name'];
            $size = $_FILES['image']['size'];
            $name = $_FILES['image']['name'];

            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));

            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime  = finfo_file($finfo, $tmp);
            finfo_close($finfo);

            if (!in_array($ext, $allowedExt) || !in_array($mime, $allowedMime)) {
                $error = "Invalid image type!";
            } elseif ($size > $maxSize) {
                $error = "Image too large (max 2MB)";
            } else {

                // DELETE OLD IMAGE (SECURE)
                if (!empty($project['image'])) {

                    $oldPath = $uploadDir . DIRECTORY_SEPARATOR . basename($project['image']);

                    if (
                        file_exists($oldPath) &&
                        is_file($oldPath) &&
                        strpos(realpath($oldPath), realpath($uploadDir)) === 0
                    ) {
                        unlink($oldPath);
                    }
                }

                // NEW FILE
                $imageName = bin2hex(random_bytes(8)) . "." . $ext;

                if (!move_uploaded_file($tmp, $uploadDir . "/" . $imageName)) {
                    $error = "Upload failed!";
                }
            }
        }

        // UPDATE DB
        if (!$error) {

            $stmt = $conn->prepare("
                UPDATE projects 
                SET title=?, category=?, description=?, tech_stack=?, image=?, status=?
                WHERE id=?
            ");

            $stmt->bind_param("ssssssi",
                $title, $category, $desc, $tech, $imageName, $status, $id
            );

            if ($stmt->execute()) {

                $success = "Project updated successfully!";

                // update UI state
                $project['title'] = $title;
                $project['category'] = $category;
                $project['description'] = $desc;
                $project['tech_stack'] = $tech;
                $project['status'] = $status;
                $project['image'] = $imageName;

            } else {
                $error = "Update failed!";
            }

            $stmt->close();
        }
    }
}
?>

<?php include '../../includes/header.php'; ?>

<div class="admin-container">

<h2>Edit Project</h2>

<?php if ($success): ?>
<div class="alert success"><?= e($success) ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert error"><?= e($error) ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data" class="admin-form">

<input type="hidden" name="csrf" value="<?= csrf_token() ?>">

<div class="form-group">
<label>Title</label>
<input type="text" name="title" value="<?= e($project['title']) ?>" required>
</div>

<div class="form-group">
<label>Category</label>
<input type="text" name="category" value="<?= e($project['category']) ?>">
</div>

<div class="form-group">
<label>Tech Stack</label>
<input type="text" name="tech_stack" value="<?= e($project['tech_stack']) ?>">
</div>

<div class="form-group">
<label>Description</label>
<textarea name="description" rows="5" required><?= e($project['description']) ?></textarea>
</div>

<div class="form-group">
<label>Status</label>
<select name="status">
<option value="Completed" <?= $project['status']=='Completed'?'selected':'' ?>>Completed</option>
<option value="Active" <?= $project['status']=='Active'?'selected':'' ?>>Active</option>
<option value="Upcoming" <?= $project['status']=='Upcoming'?'selected':'' ?>>Upcoming</option>
</select>
</div>

<div class="form-group">
<label>Current Image</label><br>
<?php if (!empty($project['image'])): ?>
<img src="<?= BASE_URL ?>uploads/projects/<?= e($project['image']) ?>" width="120">
<?php else: ?>
<p>No image</p>
<?php endif; ?>
</div>

<div class="form-group">
<label>Change Image</label>
<input type="file" name="image">
</div>

<button type="submit" class="btn btn-primary">
Update Project 🚀
</button>

</form>

</div>

<?php include '../../includes/footer.php'; ?>