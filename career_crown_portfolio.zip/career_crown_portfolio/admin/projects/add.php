<?php
require_once '../../config/db.php';
require_once '../../includes/auth.php';

require_admin();

$success = "";
$error = "";

// UPLOAD DIR
$uploadDir = __DIR__ . '/../../uploads/projects/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// HANDLE POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF (helper)
    verify_csrf();

    // sanitize
    $title    = trim($_POST['title'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $tech     = trim($_POST['tech_stack'] ?? '');
    $desc     = trim($_POST['description'] ?? '');
    $status   = $_POST['status'] ?? 'Completed';

    $imageName = "";

    // VALIDATION
    if (!$title || !$desc) {
        $error = "Title and Description required!";
    } else {

        // IMAGE UPLOAD
        if (!empty($_FILES['image']['name'])) {

            $allowedExt  = ['jpg','jpeg','png','webp'];
            $maxSize     = 2 * 1024 * 1024;

            $fileTmp  = $_FILES['image']['tmp_name'];
            $fileSize = $_FILES['image']['size'];
            $fileName = $_FILES['image']['name'];

            $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            // MIME CHECK
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime  = finfo_file($finfo, $fileTmp);
            finfo_close($finfo);

            $allowedMime = ['image/jpeg','image/png','image/webp'];

            if (!in_array($ext, $allowedExt) || !in_array($mime, $allowedMime)) {
                $error = "Invalid image type!";
            } elseif ($fileSize > $maxSize) {
                $error = "Image too large (max 2MB)!";
            } else {

                $imageName = bin2hex(random_bytes(8)) . "." . $ext;

                if (!move_uploaded_file($fileTmp, $uploadDir . $imageName)) {
                    $error = "Image upload failed!";
                }
            }
        }

        // INSERT
        if (!$error) {

            $stmt = $conn->prepare("
                INSERT INTO projects(title, category, description, tech_stack, image, status)
                VALUES (?, ?, ?, ?, ?, ?)
            ");

            $stmt->bind_param("ssssss",
                $title, $category, $desc, $tech, $imageName, $status
            );

            if ($stmt->execute()) {
                $success = "Project added successfully!";
                $title = $category = $tech = $desc = "";
                $status = "Completed";
            } else {
                $error = "Database error!";
            }

            $stmt->close();
        }
    }
}
?>

<?php include '../../includes/header.php'; ?>

<div class="admin-container">

<h2>Add New Project</h2>

<?php if ($success): ?>
<div class="alert success"><?= e($success) ?></div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert error"><?= e($error) ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data" class="admin-form">

<input type="hidden" name="csrf" value="<?= csrf_token() ?>">

<div class="form-group">
<label>Project Title</label>
<input type="text" name="title" value="<?= e($title ?? '') ?>" required>
</div>

<div class="form-group">
<label>Category</label>
<input type="text" name="category"
value="<?= e($category ?? '') ?>"
placeholder="Web App / AI / Backend">
</div>

<div class="form-group">
<label>Tech Stack</label>
<input type="text" name="tech_stack"
value="<?= e($tech ?? '') ?>"
placeholder="HTML, CSS, JS, PHP">
</div>

<div class="form-group">
<label>Description</label>
<textarea name="description" rows="5" required><?= e($desc ?? '') ?></textarea>
</div>

<div class="form-group">
<label>Status</label>
<select name="status">
<option value="Completed" <?= ($status ?? '')==='Completed'?'selected':'' ?>>Completed</option>
<option value="Active" <?= ($status ?? '')==='Active'?'selected':'' ?>>Active</option>
<option value="Upcoming" <?= ($status ?? '')==='Upcoming'?'selected':'' ?>>Upcoming</option>
</select>
</div>

<div class="form-group">
<label>Project Image</label>
<input type="file" name="image">
</div>

<button type="submit" class="btn btn-primary">
Add Project 🚀
</button>

</form>

</div>

<?php include '../../includes/footer.php'; ?>