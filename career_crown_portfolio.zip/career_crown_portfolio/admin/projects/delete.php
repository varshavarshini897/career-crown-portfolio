<?php
require_once '../../config/db.php';
require_once '../../includes/auth.php';

require_admin();

// ONLY POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('admin/projects/index.php');
}

// CSRF
verify_csrf();

// VALIDATE ID
if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    redirect('admin/projects/index.php?error=invalid');
}

$id = (int) $_POST['id'];

try {

    // FETCH PROJECT
    $stmt = $conn->prepare("SELECT image FROM projects WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if (!$result || $result->num_rows === 0) {
        $stmt->close();
        redirect('admin/projects/index.php?error=notfound');
    }

    $project = $result->fetch_assoc();
    $stmt->close();

    // DELETE IMAGE
    if (!empty($project['image'])) {

        $uploadDir = realpath(__DIR__ . "/../../uploads/projects/");

        if ($uploadDir !== false) {

            $fileName = basename($project['image']);
            $filePath = $uploadDir . DIRECTORY_SEPARATOR . $fileName;

            // ensure file is inside uploads folder
            if (
                file_exists($filePath) &&
                is_file($filePath) &&
                strpos(realpath($filePath), $uploadDir) === 0
            ) {
                unlink($filePath);
            }
        }
    }

    // DELETE RECORD
    $stmt = $conn->prepare("DELETE FROM projects WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $stmt->close();
        redirect('admin/projects/index.php?success=deleted');
    } else {
        $stmt->close();
        redirect('admin/projects/index.php?error=failed');
    }

} catch (Exception $e) {

    // optional log
    // error_log($e->getMessage());

    redirect('admin/projects/index.php?error=server');
}