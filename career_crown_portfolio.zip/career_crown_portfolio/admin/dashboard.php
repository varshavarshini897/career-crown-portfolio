<?php
require_once '../config/db.php';
require_once '../includes/auth.php';

require_admin();

// STATS
$totalProjects = $conn->query("SELECT COUNT(*) AS total FROM projects")->fetch_assoc()['total'] ?? 0;
$totalSkills   = $conn->query("SELECT COUNT(*) AS total FROM skills")->fetch_assoc()['total'] ?? 0;
$totalMessages = $conn->query("SELECT COUNT(*) AS total FROM messages")->fetch_assoc()['total'] ?? 0;

// RECENT
$recentProjects = $conn->query("SELECT title, status FROM projects ORDER BY id DESC LIMIT 5");
$recentMessages = $conn->query("SELECT name, message FROM messages ORDER BY id DESC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>

<div class="admin-wrapper">

    <!-- SIDEBAR -->
    <aside class="admin-sidebar">
        <h2>Admin Panel</h2>

        <a href="<?= BASE_URL ?>admin/dashboard.php" class="active">Dashboard</a>
        <a href="<?= BASE_URL ?>admin/projects/index.php">Projects</a>
        <a href="<?= BASE_URL ?>admin/skills/index.php">Skills</a>
        <a href="<?= BASE_URL ?>admin/messages.php">Messages</a>
        <a href="<?= BASE_URL ?>auth/logout.php" class="logout">Logout</a>
    </aside>

    <!-- MAIN -->
    <main class="admin-content">

        <h1>Dashboard Overview</h1>

        <!-- STATS -->
        <div class="admin-stats">

            <div class="stat-card">
                <h2><?= (int)$totalProjects ?></h2>
                <p>Projects</p>
            </div>

            <div class="stat-card">
                <h2><?= (int)$totalSkills ?></h2>
                <p>Skills</p>
            </div>

            <div class="stat-card">
                <h2><?= (int)$totalMessages ?></h2>
                <p>Messages</p>
            </div>

        </div>

        <!-- ACTIONS -->
        <div class="admin-actions">

            <a href="<?= BASE_URL ?>admin/projects/add.php" class="action-card">➕ Add Project</a>
            <a href="<?= BASE_URL ?>admin/projects/index.php" class="action-card">📂 View Projects</a>
            <a href="<?= BASE_URL ?>admin/skills/add.php" class="action-card">🛠 Add Skill</a>
            <a href="<?= BASE_URL ?>admin/messages.php" class="action-card">📩 Messages</a>

        </div>

        <!-- GRID -->
        <div class="dashboard-grid">

            <!-- PROJECTS -->
            <div class="dashboard-card">
                <h3>Recent Projects</h3>

                <?php if ($recentProjects && $recentProjects->num_rows > 0): ?>
                    <ul>
                        <?php while ($p = $recentProjects->fetch_assoc()): ?>
                            <li>
                                <?= e($p['title']) ?>
                                <span class="status <?= strtolower($p['status'] ?? 'completed') ?>">
                                    <?= e($p['status'] ?? 'Completed') ?>
                                </span>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php else: ?>
                    <div class="empty-box">
                        <p>No projects yet</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- MESSAGES -->
            <div class="dashboard-card">
                <h3>Recent Messages</h3>

                <?php if ($recentMessages && $recentMessages->num_rows > 0): ?>
                    <ul>
                        <?php while ($m = $recentMessages->fetch_assoc()): ?>
                            <li>
                                <strong><?= e($m['name']) ?></strong>
                                <p><?= e(substr($m['message'], 0, 60)) ?>...</p>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php else: ?>
                    <div class="empty-box">
                        <p>No messages yet</p>
                    </div>
                <?php endif; ?>
            </div>

        </div>

    </main>

</div>

</body>
</html>