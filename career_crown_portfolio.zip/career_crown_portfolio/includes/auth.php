<?php
require_once __DIR__ . '/../config/db.php';

// ================= SESSION =================
function start_session() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

// ================= CHECKS =================
function is_logged_in() {
    start_session();
    return isset($_SESSION['user_id']);
}

function is_admin() {
    start_session();
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// ================= PROTECTION =================
function require_login() {
    if (!is_logged_in()) {
        redirect('auth/login.php');
    }
}

function require_admin() {
    if (!is_admin()) {
        redirect('index.php');
    }
}
?>