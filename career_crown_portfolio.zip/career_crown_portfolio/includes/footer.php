</main>

<footer class="footer">
    <div class="container footer-grid">

        <!-- BRAND -->
        <div class="footer-brand">
            <h2>Career<span>Crown</span></h2>
            <p>
                A professional portfolio platform built with PHP, MySQL, HTML, CSS and JavaScript.
                Showcasing dynamic projects, skills and admin-managed content.
            </p>
        </div>

        <!-- LINKS -->
        <div class="footer-links">
            <h4>Quick Links</h4>

            <a href="<?= BASE_URL ?>index.php">Home</a>
            <a href="<?= BASE_URL ?>projects.php">Projects</a>
            <a href="<?= BASE_URL ?>skills.php">Skills</a>
            <a href="<?= BASE_URL ?>contact.php">Contact</a>
        </div>

        <!-- CONTACT -->
        <div class="footer-contact">
            <h4>Contact</h4>
            <p>Email: career@example.com</p>
            <p>Location: India</p>
            <p>Status: <span class="active-dot"></span> Available</p>
        </div>

    </div>

    <!-- BOTTOM -->
    <div class="footer-bottom">
        <p>© <?= date('Y') ?> Career Crown Portfolio. All rights reserved.</p>
    </div>
</footer>

<?php
// SAFE PAGE DETECTION
$currentPage = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// PAGES THAT NEED SEARCH
$searchPages = ['projects.php', 'skills.php'];
?>

<!-- MAIN JS -->
<script src="<?= BASE_URL ?>assets/js/script.js"></script>

<!-- SEARCH JS (ONLY REQUIRED PAGES) -->
<?php if (in_array($currentPage, $searchPages)): ?>
<script src="<?= BASE_URL ?>assets/js/search.js"></script>
<?php endif; ?>

</body>
</html>