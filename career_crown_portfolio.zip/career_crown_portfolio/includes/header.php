<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/auth.php';

start_session();

// current page
$current = basename($_SERVER['PHP_SELF']);

// dynamic title
$pageTitles = [
    'index.php' => 'Home',
    'projects.php' => 'Projects',
    'skills.php' => 'Skills',
    'contact.php' => 'Contact'
];

$title = $pageTitles[$current] ?? 'Portfolio';

// auth states
$isLoggedIn = is_logged_in();
$isAdmin = is_admin();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?= e($title) ?> | Career Crown</title>

<meta name="description" content="Professional portfolio website built with PHP, MySQL, HTML, CSS and JavaScript.">

<!-- CSS -->
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">

</head>
<body>

<header class="navbar">
<div class="container nav-container">

<!-- LOGO -->
<a href="<?= BASE_URL ?>index.php" class="logo">
    Career<span>Crown</span>
</a>

<!-- MOBILE -->
<button class="menu-toggle" onclick="toggleMenu()">☰</button>

<!-- NAV -->
<nav id="navMenu">

<a href="<?= BASE_URL ?>index.php"
class="<?= ($current == 'index.php') ? 'active' : '' ?>">
Home
</a>

<a href="<?= BASE_URL ?>projects.php"
class="<?= ($current == 'projects.php') ? 'active' : '' ?>">
Projects
</a>

<a href="<?= BASE_URL ?>skills.php"
class="<?= ($current == 'skills.php') ? 'active' : '' ?>">
Skills
</a>

<a href="<?= BASE_URL ?>contact.php"
class="<?= ($current == 'contact.php') ? 'active' : '' ?>">
Contact
</a>

<!-- AUTH MENU -->
<?php if ($isLoggedIn): ?>

    <?php if ($isAdmin): ?>
        <a href="<?= BASE_URL ?>admin/dashboard.php" class="admin-btn">
            Dashboard
        </a>
    <?php endif; ?>

    <a href="<?= BASE_URL ?>auth/logout.php" class="admin-btn">
        Logout
    </a>

<?php else: ?>

    <a href="<?= BASE_URL ?>auth/login.php" class="admin-btn">
        Login
    </a>

<?php endif; ?>

</nav>

</div>
</header>

<main>