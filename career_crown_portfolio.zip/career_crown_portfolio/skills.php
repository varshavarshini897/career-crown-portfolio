<?php 
require_once 'config/db.php';
include 'includes/header.php';

// FETCH SKILLS
$result = $conn->query("SELECT * FROM skills ORDER BY level DESC");
?>

<div class="container">

    <!-- HEADER -->
    <div class="section-header">
        <h2>My Skills</h2>
        <p>Technologies & expertise with real-time visualization</p>
    </div>

    <!-- SEARCH + FILTER -->
    <div class="filter-bar">
        <input type="text" id="skillSearch" placeholder="Search skills...">

        <select id="skillFilter">
            <option value="">All</option>
            <option value="frontend">Frontend</option>
            <option value="backend">Backend</option>
            <option value="database">Database</option>
        </select>
    </div>

    <!-- GRID -->
    <div class="project-grid" id="skillsContainer">

        <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>

                <?php $type = strtolower($row['type'] ?? ''); ?>

                <div class="project-card skill-card" 
                     data-type="<?= e($type) ?>">

                    <h3><?= e($row['name']) ?></h3>

                    <!-- PROGRESS -->
                    <div class="progress-bar">
                        <div style="width: <?= (int)$row['level'] ?>%"></div>
                    </div>

                    <small><?= (int)$row['level'] ?>%</small>

                    <!-- TYPE -->
                    <div class="badge">
                        <?= e($row['type']) ?>
                    </div>

                </div>

            <?php endwhile; ?>
        <?php else: ?>

            <div class="empty-box">
                <h3>No skills found</h3>
                <p>Add skills from admin panel</p>
            </div>

        <?php endif; ?>

    </div>

    <!-- NO RESULT -->
    <div id="noSkillResults" class="empty-box" style="display:none;">
        <h3>No matching skills</h3>
        <p>Try different search or filter</p>
    </div>

</div>

<!-- JS FILTER -->
<script>
const searchInput = document.getElementById("skillSearch");
const filterSelect = document.getElementById("skillFilter");
const cards = document.querySelectorAll(".skill-card");
const noResults = document.getElementById("noSkillResults");

function filterSkills() {

    const search = searchInput?.value.toLowerCase() || "";
    const filter = filterSelect?.value || "";

    let visible = 0;

    cards.forEach(card => {

        const text = card.innerText.toLowerCase();
        const type = card.dataset.type;

        const matchSearch = text.includes(search);
        const matchFilter = !filter || type === filter;

        if (matchSearch && matchFilter) {
            card.style.display = "block";
            visible++;
        } else {
            card.style.display = "none";
        }

    });

    // show empty state
    if (noResults) {
        noResults.style.display = visible === 0 ? "block" : "none";
    }
}

// EVENTS
searchInput?.addEventListener("keyup", filterSkills);
filterSelect?.addEventListener("change", filterSkills);
</script>

<?php include 'includes/footer.php'; ?>