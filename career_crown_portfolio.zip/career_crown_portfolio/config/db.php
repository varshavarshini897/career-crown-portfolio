<?php
// ================= ERROR MODE =================
// Development ke time true rakho, final submission ke time false kar sakte ho
define('APP_DEBUG', true);

if (APP_DEBUG) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

// ================= BASE URL =================
// IMPORTANT: folder name ke hisaab se set karo
define('BASE_URL', '/career_crown_portfolio/');
// Agar folder career_crown hai, then use:
// define('BASE_URL', '/career_crown/');

// ================= DATABASE CONFIG =================
$host = "localhost";
$user = "root";
$pass = "";
$db   = "career_crown";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die(APP_DEBUG ? "Database Connection Failed: " . $conn->connect_error : "Database connection failed.");
}

$conn->set_charset("utf8mb4");

// ================= SESSION START =================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ================= CSRF TOKEN =================
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

// ================= HELPER FUNCTIONS =================
function e($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    header("Location: " . BASE_URL . ltrim($path, '/'));
    exit;
}

function csrf_token() {
    return $_SESSION['csrf'] ?? '';
}

function verify_csrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
            die("Invalid request.");
        }
    }
}
?>