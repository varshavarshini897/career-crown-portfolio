<?php
require_once 'config/db.php';
include 'includes/header.php';

$success = "";
$error = "";

// HANDLE POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // CSRF VERIFY (using helper)
    verify_csrf();

    // sanitize
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    // VALIDATION
    if (!$name || !$email || !$message) {
        $error = "All required fields must be filled!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email!";
    } elseif (strlen($message) < 5) {
        $error = "Message too short!";
    } else {

        $stmt = $conn->prepare("
            INSERT INTO messages (name, email, subject, message)
            VALUES (?, ?, ?, ?)
        ");

        $stmt->bind_param("ssss", $name, $email, $subject, $message);

        if ($stmt->execute()) {
            $success = "Message sent successfully!";
            $name = $email = $subject = $message = "";
        } else {
            $error = "Server error. Try again.";
        }

        $stmt->close();
    }
}
?>

<section class="section contact-section">
<div class="container contact-grid">

    <!-- INFO -->
    <div class="contact-info">
        <h2>Get In Touch</h2>
        <p>Send your query. Admin will review from dashboard.</p>

        <div class="info-box">
            <strong>Email:</strong>
            <span>career@example.com</span>
        </div>

        <div class="info-box">
            <strong>Location:</strong>
            <span>India</span>
        </div>

        <div class="info-box">
            <strong>Status:</strong>
            <span class="active-dot"></span> Available
        </div>
    </div>

    <!-- FORM -->
    <div class="contact-form-box">

        <h3>Send Message</h3>

        <?php if ($success): ?>
            <div class="alert success"><?= e($success) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert error"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST" class="contact-form">

            <!-- CSRF -->
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">

            <div class="form-group">
                <input type="text" name="name"
                    placeholder="Your Name"
                    value="<?= e($name ?? '') ?>" required>
            </div>

            <div class="form-group">
                <input type="email" name="email"
                    placeholder="Your Email"
                    value="<?= e($email ?? '') ?>" required>
            </div>

            <div class="form-group">
                <input type="text" name="subject"
                    placeholder="Subject"
                    value="<?= e($subject ?? '') ?>">
            </div>

            <div class="form-group">
                <textarea name="message" rows="5"
                    placeholder="Your Message" required><?= e($message ?? '') ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary full-width">
                Send Message 🚀
            </button>

        </form>

    </div>

</div>
</section>

<?php include 'includes/footer.php'; ?>