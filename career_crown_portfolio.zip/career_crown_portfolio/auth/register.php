<?php
require_once '../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$msg = "";
$error = "";

// HANDLE POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verify_csrf();

    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // VALIDATION
    if (!$name || !$email || !$password) {
        $error = "All fields are required!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email!";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters!";
    } elseif (!preg_match('/[A-Z]/', $password)) {
        $error = "Password must contain at least 1 uppercase letter!";
    } elseif (!preg_match('/[0-9]/', $password)) {
        $error = "Password must contain at least 1 number!";
    } else {

        // CHECK EMAIL
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $res = $check->get_result();

        if ($res->num_rows > 0) {
            $error = "Email already registered!";
        } else {

            $passHash = password_hash($password, PASSWORD_DEFAULT);

            // DEFAULT ROLE = user
            $role = "user";

            $stmt = $conn->prepare("
                INSERT INTO users(name,email,password,role)
                VALUES(?,?,?,?)
            ");

            $stmt->bind_param("ssss", $name, $email, $passHash, $role);

            if ($stmt->execute()) {

                // REDIRECT AFTER SUCCESS
                header("Location: login.php?registered=1");
                exit;

            } else {
                $error = "Something went wrong!";
            }

            $stmt->close();
        }

        $check->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="auth-container">

<h2>Register</h2>

<?php if ($error): ?>
<div class="alert error"><?= e($error) ?></div>
<?php endif; ?>

<form method="POST" class="auth-form">

<input type="hidden" name="csrf" value="<?= csrf_token() ?>">

<div class="form-group">
<input type="text" name="name"
value="<?= e($name ?? '') ?>"
placeholder="Full Name" required>
</div>

<div class="form-group">
<input type="email" name="email"
value="<?= e($email ?? '') ?>"
placeholder="Email" required>
</div>

<div class="form-group">
<input type="password" name="password"
placeholder="Password (min 6 chars, 1 uppercase, 1 number)" required>
</div>

<button class="btn btn-primary">Register</button>

<p>
Already have an account?
<a href="login.php">Login</a>
</p>

</form>

</div>

</body>
</html>