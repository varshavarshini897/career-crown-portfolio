<?php
require_once '../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// UNSET SESSION DATA
$_SESSION = [];
session_unset();

// DESTROY SESSION
session_destroy();

// DELETE SESSION COOKIE
if (ini_get("session.use_cookies")) {

    $params = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// OPTIONAL: REGENERATE SESSION (extra safety)
session_start();
session_regenerate_id(true);

// REDIRECT (USING BASE_URL)
header("Location: " . BASE_URL . "auth/login.php");
exit;