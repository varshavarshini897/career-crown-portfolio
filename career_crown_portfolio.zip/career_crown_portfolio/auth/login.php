<?php
require_once '../config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$error = "";

// HANDLE POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    verify_csrf();

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // VALIDATION
    if (!$email || !$password) {
        $error = "All fields required!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email!";
    } else {

        // FETCH USER (ONLY REQUIRED FIELDS)
        $stmt = $conn->prepare("
            SELECT id, name, password, role 
            FROM users 
            WHERE email = ?
        ");
        $stmt->bind_param("s", $email);
        $stmt->execute();

        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {

            session_regenerate_id(true);

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role']    = $user['role'];
            $_SESSION['name']    = $user['name'];

            // ROLE REDIRECT
            if ($user['role'] === 'admin') {
                header("Location: ../admin/dashboard.php");
            } else {
                header("Location: ../index.php");
            }
            exit;

        } else {
            $error = "Invalid email or password!";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<div class="auth-container">

<h2>Login</h2>

<?php if (isset($_GET['registered'])): ?>
<div class="alert success">Registration successful! Please login.</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert error"><?= e($error) ?></div>
<?php endif; ?>

<form method="POST" class="auth-form">

<input type="hidden" name="csrf" value="<?= csrf_token() ?>">

<div class="form-group">
<input type="email" name="email"
placeholder="Email"
value="<?= e($email ?? '') ?>" required>
</div>

<div class="form-group">
<input type="password" name="password"
placeholder="Password" required>
</div>

<button class="btn btn-primary">Login</button>

<p>
Don't have an account?
<a href="register.php">Register</a>
</p>

</form>

</div>

</body>
</html>